import Header from "../components/header";

const Schat = () => {
    return (
        <div>
            <div className="Container bg-secondary p-3">
                <div className="row">
                    <div className="col-12">
                        <a href="/setting"><i class="fa-solid fa-arrow-left fa-2x text-light ps-4 pe-5"></i></a> <big><b className="open text-light">Чаты</b></big>
                    </div>
                </div>
            </div>
            <div className="Container bg-dark">
                <div className="row">
                    <div className="col-12 p-3 ps-5">
                        <b className="text-secondary">Экран</b>
                    </div>
                </div>
                <div className="row">
                    <div className="col-1 ps-5 p-3">
                        <i class="fa-solid fa-sun fa-2x text-secondary"></i>
                    </div>
                    <div className="col-11 pt-2">
                        <big><b className="text-light">Тема</b></big><br></br>
                        <small><b className="text-secondary">По умолчанию</b></small>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default Schat;